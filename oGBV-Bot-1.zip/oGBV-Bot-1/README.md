# oGBV-Bot
A chatbot presenting the findings on research conducted on online gender based violence by pollicy.
This Bot was build on botui framework and its demo can be found here https://botui.org/ and its docs here https://docs.botui.org/

# BotUI Chatbot Tutorial
Demo of how to build a simple linear chatbot with BotUI.

The chatbot runs in a simple html page. It can be included in any website. It is
completely front-end based and does not require a backend.

## How to Install & Run
Just download the `.zip` or clone this project. Then open `index.html` in your
browser. That's it!

## Resources to consider before any coding
https://medium.com/better-programming/a-beginners-guide-to-botui-framework-for-chatbot-ui-a4e6d9a4a74
